function showJS(){
    // para 1
    document.getElementById("para1").style.display = "block";
    document.getElementById("para1").style.textAlign = "center";
    document.getElementById("para1").innerHTML="JavaScript is the most popular language.";
    // para 2
    document.getElementById("para2").style.display = "block";
    document.getElementById("para2").style.textAlign = "center";
    document.getElementById("para2").innerHTML = "JavaScript is the dynamic-typed programming language.";
    // para 3
    document.getElementById("para3").style.display = "block";
    document.getElementById("para3").style.textAlign = "center";
    document.getElementById("para3").innerHTML= "JavaScript is supported by all major web browsers making it a universal language for web development.";
}
function showJava(){
    // Java 1
    document.getElementById("java1").style.display = "block";
    document.getElementById("java1").style.textAlign = "center";
    document.getElementById("java1").innerHTML="Java is also a popular programming language.";
    // Java 2
    document.getElementById("java2").style.display = "block";
    document.getElementById("java2").style.textAlign = "center";
    document.getElementById("java2").innerHTML = "Java is the static-typed programming language.";
    // Java 3
    document.getElementById("java3").style.display = "block";
    document.getElementById("java3").style.textAlign = "center";
    document.getElementById("java3").innerHTML = "Java is used to develop mobile apps, web apps, desktop apps, games and much more.";
}
function notShowJS(){
    document.getElementById("para1").style.display = "none";
    document.getElementById("para2").style.display = "none";
    document.getElementById("para3").style.display = "none";
}
function notShowJava(){
    document.getElementById("java1").style.display = "none";
    document.getElementById("java2").style.display = "none";
    document.getElementById("java3").style.display = "none";
}
function helloWorld(){
    document.getElementsByClassName("hw")[0].innerHTML="Hello World";
}
function noHello(){
    document.getElementsByClassName("hw")[0].innerHTML="";
}
function ans(){
    var x = 10; var y=20;
    var sum = x+y;
    document.getElementsByClassName("result")[0].innerHTML=sum;
}
function reSult(){
    document.getElementsByClassName("result")[0].innerHTML="The result";
}
function enterName(){
    var name = document.getElementsByClassName("inputText")[0].value;
    alert("Hello "+name+", nice to meet you. I hope you'll like this js testing.");
}
function obj(){
    var laptop = {
        PC_Name: "Asus",
        PC_Price: 200,
        PC_Color: "Black"
    };
    document.getElementsByClassName("objectCreate")[0].innerHTML="Type of Laptop <br>"+ 
    "Name : "+laptop.PC_Name+"<br> Color : "+laptop.PC_Color+"<br> Price : "+laptop.PC_Price+"$";
}
function notObj(){
    document.getElementsByClassName("objectCreate")[0].innerHTML = "In here, you'll see the laptop object.";
}
function expon(){
    let a = document.getElementsByClassName("inputNum1")[0].value;
    let b = document.getElementsByClassName("inputNum2")[0].value;
    let expo = (a **=b);
    document.getElementsByClassName("totalResult")[0].innerHTML = expo;
}
function notExpon(){
    document.getElementsByClassName("totalResult")[0].innerHTML = "Total Result";
}


function log(){
    var alpha = 20;
    var beta = 15;
    document.getElementsByClassName("logicalP")[0].innerHTML = (alpha==beta)&&(alpha!=alpha);
}
function notlog(){
    document.getElementsByClassName("logicalP")[0].innerHTML = "Let alpha = 20, beta = 15,<br> Show in here <br>(alpha == beta) && (alpha != alpha)"
}