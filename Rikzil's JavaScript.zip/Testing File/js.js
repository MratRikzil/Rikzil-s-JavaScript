// function person(name, age, email,address){
//     console.log('Name: '+name);
//     console.log('Age: '+age);
//     console.log('Email: '+email);
//     console.log('Address: '+address);
// }
// person('Rikzil',25,'rikzil@gmail.com','Yangon');
// let mySelf =['Mrat Naing',25,'mratnaing@gmail.com','Insein'];

// console.log('Name: '+mySelf[0]);
// console.log('Age: '+mySelf[1]);
// console.log('Email: '+mySelf[2]);
// console.log('Address: '+mySelf[3]);
let engMark;
let physMark;
let chemMark;
function studentTotalMarks(engMark,physMark,chemMark){
    var result = engMark+physMark+chemMark;
    if(result>=240){
        console.log('Pass with D.');
    }
    else if(result>150 && result<240){
        console.log('Pass');
    }
    else{console.log('Fail.')};
    console.log('The total marks '+result);
}
studentTotalMarks(40,55,47);
console.log();
function averageMarks(engMark,physMark,chemMark){
   return (engMark+physMark+chemMark)/3;
}

let price, discount, unit;
function calculationTotalWithDis(price,unit){
    discount = 0.1;
    if(unit>=4){
        return (price*unit)-(price*unit*discount);
    }
    return price*unit;

}
let totalResult = calculationTotalWithDis(200,3);
console.log(totalResult);

let salary =()=>{
    let basicSalary = 10000;
    let tax = 100;
    let OT  = 4;
    let oTPayment= 50;
    
    var amount= basicSalary+(OT*oTPayment)-tax;
    console.log('My salary: '+amount);
    
}
salary();