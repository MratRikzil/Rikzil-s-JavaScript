// console.log('Hello, Welcome Back');
// let hello = 'Rikzil';
// console.log('I am '+hello+'.')
// let fristName = 'Mrat', lastName = 'Naing';
// console.log(fristName+' '+lastName);
// const insRate = 4;
// console.log(insRate);

let people = {
    name:'Mrat', 
    age:25
}
// Dot Notation
people.name = 'Rikzil'

// Bracket Notation
let hib = 'name';
people[hib] = 'Soe'
console.log(people.name);

