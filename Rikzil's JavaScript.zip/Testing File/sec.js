// let selectorColors =['red','blue'];
// selectorColors[2]= 20;
// console.log(selectorColors.length);
//Performing a task
function great(name, text){
    console.log('Hi '+name+'. '+text);
}
great('Rikzil', 'Welcome.');
great('Soe', 'Do u love me?');

// Calculation
function calculation(x,y){
    return x*y/x+y-x;
}

console.log(calculation(5,2));